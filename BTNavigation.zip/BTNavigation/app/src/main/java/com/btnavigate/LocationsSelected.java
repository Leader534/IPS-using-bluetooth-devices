package com.btnavigate;

public class LocationsSelected {

    public static final String HOD = "HOD";
    public static final String OSSL = "OSSL Lab";
    public static final String DSA = "DSA Lab";
    private static String fromSourceLoc;
    private static String toDestiLoc;

    public static String getFromSourceLoc() {
        return fromSourceLoc;
    }

    public static void setFromSourceLoc(String fromSourceLoc) {
        LocationsSelected.fromSourceLoc = fromSourceLoc;
    }

    public static String getToDestiLoc() {
        return toDestiLoc;
    }

    public static void setToDestiLoc(String toDestiLoc) {
        LocationsSelected.toDestiLoc = toDestiLoc;
    }
}
