package com.btnavigate.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.btnavigate.R;
import com.btnavigate.SaveBitmapResult;
import com.jsibbold.zoomage.ZoomageView;

public class ZoomedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zoomed);
        if (SaveBitmapResult.getBitmapRedrawn() != null) {
            ((ZoomageView) findViewById(R.id.myZoomageView)).setImageBitmap(SaveBitmapResult.getBitmapRedrawn());
        }
        ((Button) findViewById(R.id.button_dismiss)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
