package com.btnavigate.ui;

import android.Manifest;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.btnavigate.BTfoundBR;
import com.btnavigate.DevicesSharedPref;
import com.btnavigate.LocationsSelected;
import com.btnavigate.R;
import com.btnavigate.SaveBitmapResult;
import com.btnavigate.ThinkingEngine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.SplittableRandom;
import java.util.Timer;
import java.util.TimerTask;

public class NavigateActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private static final String TAG = "TAG";
    private static final int RCODE_ENABLE_BT = 102;
    private static final long PERIOD_ = 80_000;

    private static final String SPEAK_NOW = "Speak now";
    private static final int OSSL_X = 638;
    private static final int OSSL_Y = 337;
    private static final int OSSL_YEnd = 350;
    private static final int OSSL_XEnd = 638;
    private static final int HOD_X = 556;   //considering COMP as HOD
    private static final int HOD_Y = 337;
    private static final int HOD_YEnd = 350;
    private static final int HOD_XEnd = 557;
    private static final int HODIT_X = 638;
    private static final int HODIT_Y = 638;
    private static final int HODIT_YEnd = 638;
    private static final int HODIT_XEnd = 638;
    private static final int DSA_X = 688;
    private static final int DSA_Y = 337;
    private static final int DSA_YEnd = 350;
    private static final int DSA_XEnd = 688;

    private BluetoothAdapter bluetoothAdapter;
    private BTfoundBR broadcastReceiver;
    private IntentFilter filter;
    private static final int RC_COARSE = 101;
    private TextView rssiTV;
    private Timer timer = new Timer();
    private TimerTask mRssiTask;
    private int count = 0;
    private String stringHistory = "\n";
    private boolean found;
    private String fromSource;
    private Spinner spinFrom, spinTo;
    private ArrayAdapter adaptFrom, adaptTo;
    private ArrayList<String> list, listFrom;
    private String comment;
    private Dialog dialogTest, dialogZoom;
    private Bitmap bitmap;
    private MenuItem logMenuItem, scanMenuItem;
    private boolean startNavClicked;
    private Button btnStartNav;
    //speech
    private TextToSpeech tts;
    private boolean isTTSready;
    private int tts_id = 0;
    private boolean noInputNeeded;
    private ImageView imageView;
    private String speakCmd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigate);
        fromSource = getIntent().getStringExtra("SOURCE_KEY");
        listFrom = new ArrayList<>();
        listFrom.add(fromSource);
        initiUI();
        initData();
        //drawNavigation();
    }

/*
    private void drawNavigation() {
        //Create a new image bitmap and attach a brand new canvas to it
        Bitmap tempBitmap = Bitmap.createBitmap(myBitmap.getWidth(), myBitmap.getHeight(), Bitmap.Config.RGB_565);
        Canvas tempCanvas = new Canvas(tempBitmap);

        //Draw the image bitmap into the cavas
        tempCanvas.drawBitmap(myBitmap, 0, 0, null);

        //Draw everything else you want into the canvas, in this example a rectangle with rounded edges
        tempCanvas.drawRoundRect(new RectF(x1, y1, x2, y2), 2, 2, myPaint);

        //Attach the canvas to the ImageView
        myImageView.setImageDrawable(new BitmapDrawable(getResources(), tempBitmap));
    }
*/

    private void initiUI() {
        rssiTV = findViewById(R.id.tv_rssi);
        imageView = findViewById(R.id.imageView);
        rssiTV.setVisibility(View.INVISIBLE);
        btnStartNav = findViewById(R.id.button_startnavig);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            exitApp();
        } else if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, RCODE_ENABLE_BT);
        }
        list = new ArrayList<>();
        list.addAll(Arrays.asList(this.getString(R.string.select_desti_poszero), this.getString(R.string.hod),
                this.getString(R.string.ossl),
                this.getString(R.string.dsa)));
        if (fromSource != null) list.remove(fromSource);
        spinFrom = (Spinner) findViewById(R.id.spinnerfrom);
        spinTo = (Spinner) findViewById(R.id.spinnerto);
        adaptFrom = new ArrayAdapter<String>(NavigateActivity.this, R.layout.spinitem, R.id.txt, listFrom);
        spinFrom.setAdapter(adaptFrom);
        spinFrom.setEnabled(false);
        adaptTo = new ArrayAdapter<String>(NavigateActivity.this, R.layout.spinitem, R.id.txt, list);
        spinTo.setAdapter(adaptTo);
        spinTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                Log.i(TAG, "onItemSelected: " + pos + " " + DevicesSharedPref.getSeconddevice(NavigateActivity.this));
                if (pos != 0) {
                    btnStartNav.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkLocationPermission();
        if (broadcastReceiver != null && filter != null)
            registerReceiver(broadcastReceiver, filter);
    }

    private void exitApp() {
        Toast.makeText(this, "Your device lacks bluetooth", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, RC_COARSE);
        else if (startNavClicked) startDiscovering();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RCODE_ENABLE_BT) {
            if (resultCode == RESULT_CANCELED) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, RCODE_ENABLE_BT);
            } else {
                checkLocationPermission();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_settings_nav, menu);
        logMenuItem = menu.findItem(R.id.mi_test);
        logMenuItem.setVisible(false);
        //scan btn
        scanMenuItem = menu.findItem(R.id.mi_scan);
        scanMenuItem.setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.mi_setting) {
            goTOSettings();
        } else if (item.getItemId() == R.id.mi_test) {
            dialogShowTest();
        } else if (item.getItemId() == R.id.mi_scan) {
            startDiscoveringOnce();
        }
        return super.onOptionsItemSelected(item);
    }

    private void goTOSettings() {
        Intent intent = new Intent(NavigateActivity.this, SettingsEditDevicesActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (RC_COARSE == requestCode && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (startNavClicked) startDiscovering();
        } else {
            ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        }
    }

    private void startDiscovering() {
        //intentfilter
        if (broadcastReceiver == null) {
            if (filter == null) {
                filter = new IntentFilter();
                filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                filter.addAction(BluetoothDevice.ACTION_FOUND);
            }
            //filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
            //filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            broadcastReceiver = new BTfoundBR();
            broadcastReceiver.setActivity(this);
            registerReceiver(broadcastReceiver, filter);
        }
        if (startNavClicked) {
            if (mRssiTask == null) {
                mRssiTask = new TimerTask() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (scanMenuItem.isVisible())
                                    scanMenuItem.setVisible(false);
                            }
                        });
                        if (!found) {
                            Log.i(TAG, "run: befoe blueToothDiscovery" + found);
                            blueToothDiscovery();
                            found = true;
                            Log.i(TAG, "run: after blueToothDiscovery " + found);
                        }
                        count++;
                        Log.i(TAG, "mRssiTask: " + count);
                    }
                };
                timer.schedule(mRssiTask, 4_000, PERIOD_);
            }
        }
    }

    private void blueToothDiscovery() {
        if (bluetoothAdapter != null) {
            cancelDisovery();
            //bluetooth is discovered method
            bluetoothAdapter.startDiscovery();
        } else {
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            cancelDisovery();
            bluetoothAdapter.startDiscovery();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        /*if (broadcastReceiver != null) {
            unregisterReceiver(broadcastReceiver);
            broadcastReceiver = null;
        }*/
    }

    @Override
    protected void onDestroy() {
        if (broadcastReceiver != null) {
            unregisterReceiver(broadcastReceiver);
            broadcastReceiver = null;
        }
        stopNavigation();
        if (tts != null && tts.isSpeaking()) {
            tts.stop();
            tts.shutdown();
        }
        tts = null;
        SaveBitmapResult.setBitmapRedrawn(null);
        super.onDestroy();
    }

    private void cancelDisovery() {
        if (bluetoothAdapter != null && bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
            //bluetoothAdapter.disable();

        }
    }

    private void initData() {
        tts = new TextToSpeech(this, this);
    }

    public void showRSSI(String s) {
        Log.i(TAG, "showRSSI: " + s);
        stringHistory = stringHistory + s;
        Log.i(TAG, "showRSSI: " + stringHistory);
        if (!s.isEmpty()) {
            showOptionsMenu();
            String[] data = s.split("\\n");
            String[] comment = data[0].split(",");
            if (!comment[3].equalsIgnoreCase("null")) {
                speakCmd = comment[3];
                speakOut(comment[3], true);
            }
            if (comment[3].contains("reached")) {
                stopNavigation();
            }
            rssiTV.setText(String.format(getResources().getString(R.string.rssi), comment[2], speakCmd, comment[0]));
        } else {
            rssiTV.setText("Detecting...");
        }
    }

    private void stopNavigation() {
        cancelDisovery();
        bluetoothAdapter = null;
        if (timer != null) timer.cancel();
        ThinkingEngine.setFirstCmdSpoken(false);
        //BTfoundBR.foundBothInRange = false;
    }

    private void showOptionsMenu() {
        if (logMenuItem != null) {
            logMenuItem.setVisible(true);
        }
    }

    public void foundCompleted() {
        found = false;
        Log.i(TAG, "foundCompleted: found" + found);
    }

    private void dialogShowTest() {
        dialogTest = new Dialog(NavigateActivity.this);
        final View dialogView = getLayoutInflater().inflate(R.layout.custom_test_dialog, null);
        if (stringHistory != null)
            ((TextView) dialogView.findViewById(R.id.tv_rssi)).setText(stringHistory);
        ((Button) dialogView.findViewById(R.id.button_dismiss)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialogTest != null && dialogTest.isShowing())
                    dialogTest.dismiss();
            }
        });
        dialogTest.setCancelable(false);
        dialogTest.setContentView(dialogView);

        if (dialogTest != null)
            dialogTest.show();
    }

    private void goToZoomedActivity() {
        Intent intent = new Intent(NavigateActivity.this, ZoomedActivity.class);
        startActivity(intent);
    }

    public void onZoomTapped(View view) {
        goToZoomedActivity();
    }

    public void onStartNavClicked(View view) {
        btnStartNav.setEnabled(false);
        btnStartNav.setText("Navigation Started");
        LocationsSelected.setToDestiLoc((String) spinTo.getSelectedItem());
        spinTo.setEnabled(false);
        draw();
        rssiTV.setVisibility(View.VISIBLE);
        startDiscoveringOnce();
    }

    private void autoScan() {
        startNavClicked = true;
        startDiscovering();
    }

    private void startDiscoveringOnce() {
        if (scanMenuItem != null && scanMenuItem.isVisible()){
            scanMenuItem.setVisible(false);
        }
        if (broadcastReceiver == null) {
            if (filter == null) {
                filter = new IntentFilter();
                filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                filter.addAction(BluetoothDevice.ACTION_FOUND);
            }
            //filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
            //filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            broadcastReceiver = new BTfoundBR();
            broadcastReceiver.setActivity(this);
            registerReceiver(broadcastReceiver, filter);
        }
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        cancelDisovery();
        bluetoothAdapter.startDiscovery();
    }

    private void draw() {
        //start progressbar
        BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
        Bitmap bmp = drawable.getBitmap().copy(Bitmap.Config.RGB_565, true);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();
        p.setColor(Color.BLACK);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(3.0f);
        int x = 0, y = 0, xEnd = 0, yEnd = 0;
        int[] connectinLines = new int[4];
        Log.i(TAG, "draw: " + LocationsSelected.getFromSourceLoc() + LocationsSelected.getToDestiLoc());
        switch (LocationsSelected.getFromSourceLoc()) {
            case LocationsSelected.HOD:
                switch (LocationsSelected.getToDestiLoc()) {
                    case LocationsSelected.OSSL:
                        //main line
                        x = OSSL_X;
                        y = OSSL_Y;
                        xEnd = HOD_X;
                        yEnd = HOD_Y;
                        //lines related to rooms
                        connectinLines[0] = OSSL_XEnd;
                        connectinLines[1] = OSSL_YEnd;
                        connectinLines[2] = HOD_XEnd;
                        connectinLines[3] = HOD_YEnd;
                        break;
                    case LocationsSelected.DSA:
                        x = DSA_X;
                        y = DSA_Y;
                        xEnd = HOD_X;
                        yEnd = HOD_Y;
                        //lines related to rooms
                        connectinLines[0] = DSA_XEnd;
                        connectinLines[1] = DSA_YEnd;
                        connectinLines[2] = HOD_XEnd;
                        connectinLines[3] = HOD_YEnd;
                }
                break;
            case LocationsSelected.OSSL:
                switch (LocationsSelected.getToDestiLoc()) {
                    case LocationsSelected.HOD:
                        x = OSSL_X;
                        y = OSSL_Y;
                        xEnd = HOD_X;
                        yEnd = HOD_Y;
                        //lines related to rooms
                        connectinLines[0] = OSSL_XEnd;
                        connectinLines[1] = OSSL_YEnd;
                        connectinLines[2] = HOD_XEnd;
                        connectinLines[3] = HOD_YEnd;
                        break;
                    case LocationsSelected.DSA:
                        x = OSSL_X;
                        y = OSSL_Y;
                        xEnd = DSA_X;
                        yEnd = DSA_Y;
                        //lines related to rooms
                        connectinLines[0] = OSSL_XEnd;
                        connectinLines[1] = OSSL_YEnd;
                        connectinLines[2] = DSA_XEnd;
                        connectinLines[3] = DSA_YEnd;
                }
                break;
            case LocationsSelected.DSA:
                switch (LocationsSelected.getToDestiLoc()) {
                    case LocationsSelected.HOD:
                        x = HOD_X;
                        y = HOD_Y;
                        xEnd = DSA_X;
                        yEnd = DSA_Y;
                        //lines related to rooms
                        connectinLines[0] = HOD_XEnd;
                        connectinLines[1] = HOD_YEnd;
                        connectinLines[2] = DSA_XEnd;
                        connectinLines[3] = DSA_YEnd;
                        break;
                    case LocationsSelected.OSSL:
                        x = OSSL_X;
                        y = OSSL_Y;
                        xEnd = DSA_X;
                        yEnd = DSA_Y;
                        //lines related to rooms
                        connectinLines[0] = OSSL_XEnd;
                        connectinLines[1] = OSSL_YEnd;
                        connectinLines[2] = DSA_XEnd;
                        connectinLines[3] = DSA_YEnd;
                }
        }

        Log.i(TAG, "draw: " + x + " " + y + " " + xEnd + " " + yEnd + " " + connectinLines.length);
        if (x == 0) return;
        c.drawLine(x, y, xEnd, yEnd, p);
        c.drawLine(connectinLines[0], connectinLines[1], x, y, p);
        c.drawLine(xEnd, yEnd, connectinLines[2], connectinLines[3], p);
        p.setColor(Color.GREEN);
        c.drawCircle(connectinLines[0], connectinLines[1], 3.0f, p);
        p.setColor(Color.RED);
        c.drawCircle(connectinLines[2], connectinLines[3], 3.0f, p);
        //c.drawLine(437, 255, 438, 213, p);
        imageView.setImageBitmap(bmp);
        SaveBitmapResult.setBitmapRedrawn(bmp);
        //end progressbar
    }

    private void speakOut(String s, boolean noInputNeeded) {
        tts_id++;
        this.noInputNeeded = noInputNeeded;
        HashMap<String, String> mapTTSid = new HashMap<>();
        mapTTSid.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, String.valueOf(tts_id));
        Log.i(TAG, "speakOut: isSpeaking? " + tts.isSpeaking() + "\n" + s);
        tts.speak(s, TextToSpeech.QUEUE_ADD, mapTTSid);
    }

    @Override
    public void onInit(int status) {
        //takes 3s
        if (status == TextToSpeech.SUCCESS) {
            int resultLang = tts.setLanguage(Locale.getDefault());
            Log.i(TAG, "onInit: " + resultLang);
            if (resultLang == TextToSpeech.LANG_MISSING_DATA ||
                    resultLang == TextToSpeech.LANG_NOT_SUPPORTED) {
                // missing data, install it
                Intent install = new Intent();
                install.setAction(
                        TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(install);
            } else {
                isTTSready = true;
            }
        }
    }

    public void startTimer() {
        autoScan();
    }

    public void notFoundMAkeScanVisible() {
        if (scanMenuItem != null && !scanMenuItem.isVisible()) {
            scanMenuItem.setVisible(true);
        }
    }
}
