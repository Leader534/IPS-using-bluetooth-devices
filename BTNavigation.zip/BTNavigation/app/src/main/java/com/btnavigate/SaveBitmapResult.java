package com.btnavigate;

import android.graphics.Bitmap;

public class SaveBitmapResult {
    private static Bitmap bitmapRedrawn;

    public static Bitmap getBitmapRedrawn() {
        return bitmapRedrawn;
    }

    public static void setBitmapRedrawn(Bitmap bitmapRedrawn) {
        SaveBitmapResult.bitmapRedrawn = bitmapRedrawn;
    }

}
