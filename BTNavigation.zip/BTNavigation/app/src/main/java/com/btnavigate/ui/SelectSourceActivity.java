package com.btnavigate.ui;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import com.btnavigate.DevicesSharedPref;
import com.btnavigate.LocationsSelected;
import com.btnavigate.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class SelectSourceActivity extends AppCompatActivity {

    private FloatingActionButton fab;
    private ListView listViewSource;
    private ArrayList<String> list;
    private ArrayAdapter arrayAdapter;
    private String selectedItemSource;
    private View pastView;
    private TextView plsNoteTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_source);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab = findViewById(R.id.fab);
        listViewSource = findViewById(R.id.list_source);
        plsNoteTV = findViewById(R.id.txt_plsnote);
        list = new ArrayList<>();
        list.addAll(Arrays.asList(this.getString(R.string.select_source_poszero), this.getString(R.string.hod),
                this.getString(R.string.ossl),
                this.getString(R.string.dsa)));
        arrayAdapter = new ArrayAdapter<>(SelectSourceActivity.this, R.layout.spinitem, R.id.txt, list);
        //arrayAdapter.setDropDownViewResource(R.layout.spinitem);
        listViewSource.setAdapter(arrayAdapter);
        listViewSource.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    return;
                }
                if (((ColorDrawable) view.getBackground()).getColor() == Color.LTGRAY
                )
                    return;
                view.setBackgroundColor(Color.LTGRAY);
                selectedItemSource = list.get(position);
                //set the rest as normal color
                if (pastView != null) {
                    pastView.setBackgroundColor(Color.WHITE);
                }
                pastView = view;

                if (list != null && list.size() > 0) {
                    plsNoteTV.setText("*Please Note: Device " + DevicesSharedPref.getFirstdeviceNAME(SelectSourceActivity.this) +
                            " should be placed at " + selectedItemSource);
                    plsNoteTV.setVisibility(View.VISIBLE);
                    if (fab.isOrWillBeHidden())
                        fab.show();
                }
            }
        });
        fab.hide();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fab.isOrWillBeShown()) {
                    if (selectedItemSource != null) {
                        LocationsSelected.setFromSourceLoc(selectedItemSource);
                        goToNavigation();
                    }
                }
            }
        });
        if (DevicesSharedPref.getFirstdevice(SelectSourceActivity.this).isEmpty() &&
                DevicesSharedPref.getSeconddevice(SelectSourceActivity.this).isEmpty()) {
            goToSettings();
        }
    }

    private void goToSettings() {
        Intent intent = new Intent(SelectSourceActivity.this, SettingsEditDevicesActivity.class);
        startActivity(intent);
        finish();
    }

    private void goToNavigation() {
        Intent intent = new Intent(SelectSourceActivity.this, NavigateActivity.class);
        intent.putExtra("SOURCE_KEY", selectedItemSource);
        startActivity(intent);
        //finish();
    }
}
