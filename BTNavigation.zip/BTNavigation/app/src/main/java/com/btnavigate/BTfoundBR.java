package com.btnavigate;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.btnavigate.ui.NavigateActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.bluetooth.BluetoothDevice.EXTRA_RSSI;

public class BTfoundBR extends BroadcastReceiver {

    public boolean foundBothInRange;
    private NavigateActivity activity;
    private static final String TAG = "BTfoundBR";
    private int countFoundAll;
    private boolean foundDev;
    private Context context;
    private int countDev1;
    private int countDev2;

    public BTfoundBR() {
        Log.i(TAG, "BTfoundBR: foundBothInRange" + foundBothInRange + " count" + countDev1 + countDev2);
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        if (intent != null) {
            String action = intent.getAction();
            Log.i(TAG, "onReceive: " + action);
            if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                Log.d(TAG, "onReceive: ACTION_DISCOVERY_FINISHED");
                Log.d("foundDev", "in ACTION_DISCOVERY_FINISHED: " + foundDev +foundBothInRange);
                if (!foundBothInRange) {
                    countFoundAll = 0;
                    countDev1 = 0;
                    countDev2 = 0;
                    activity.notFoundMAkeScanVisible();
                    return;
                }
                if (!foundDev) activity.foundCompleted();
                //countFoundAll = 0;
            } else if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                foundDev = false;
                Log.d("foundDev", "before ACTION_FOUND: " + foundDev);
                foundDevices(intent);
            } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
                Log.i(TAG, "onReceive: ACTION_STATE_CHANGED");
            }
        }
    }

    private void foundDevices(Intent intent) {
        BluetoothDevice deviceTemp = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        if (deviceTemp == null) {
            return;
        }
        int rssi = intent.getShortExtra(EXTRA_RSSI, Short.MIN_VALUE);
        Log.i(TAG, "foundDevices:nofilter rssi " + rssi + " " + deviceTemp.getName());
        int value = 0;
        String devNAME = null, comment = null;
        if ((value = isMyDeviceToConnectInList(deviceTemp)) != 0) {
            if (activity != null) {
                if (!foundBothInRange) {
                    countFoundAll++;
                    Log.i(TAG, "checkHERE: " + countFoundAll +foundBothInRange);

                    inRange(deviceTemp);
                    if (countDev1 >= 1 && countDev2 >= 1) {
                        foundBothInRange = true;
                        countDev1 = 0;
                        countDev2 = 0;
                        activity.startTimer();
                        return;
                    }
                    if (countFoundAll >= 2) {
                        Log.d("foundDev", "inside (countFoundAll >= 2): " + foundDev);
                        countFoundAll = 0;
                        foundDev = true;
                        activity.notFoundMAkeScanVisible();
                    }
                    return;
                }
                Log.d(TAG, "checkHERE: " + rssi + " " + value);
                if (value == 1) {
                    int rssiDev1 = rssi;
                    devNAME = DevicesSharedPref.getFirstdeviceNAME(context);
                    comment = ThinkingEngine.getCommands(rssiDev1, value);
                    activity.showRSSI(devNAME + "," + deviceTemp.getAddress() + "," + rssi + "," + comment + "\n"/* + getCurrentTime() + "\n"*/);

                } else {  //2
                    int rssiDev2 = rssi;
                    devNAME = DevicesSharedPref.getSeconddeviceNAME(context);
                    comment = ThinkingEngine.getCommands(rssiDev2, value);
                    activity.showRSSI(devNAME + "," + deviceTemp.getAddress() + "," + rssi + "," + comment + "\n"/* + getCurrentTime() + "\n"*/);

                }
               /* if (comment == null) {
                    Log.i(TAG, "foundDevices: comment is null");
                    return;
                }*/
                Log.i(TAG, "onReceive:->added " + deviceTemp.getName() + " " + deviceTemp.getAddress() + " " + rssi);
                countFoundAll++;
                Log.i(TAG, "countFoundAll: " + countFoundAll);
                if (countFoundAll >= 1) {
                    foundDev = true;
                    Log.d("foundDev", "inside (countFoundAll >= 1): " + foundDev);
                    countFoundAll = 0;
                    activity.foundCompleted();
                }
            }
        } else {
            Log.i(TAG, "ignore: not in my list");
        }
    }

    private void inRange(BluetoothDevice deviceTemp) {
        String DEV1 = DevicesSharedPref.getFirstdevice(context);  //moto
        String DEV2 = DevicesSharedPref.getSeconddevice(context);  //galaxy on7

        if (deviceTemp.getAddress().equals(DEV2)) {
            ++countDev1;
        } else if (deviceTemp.getAddress().equals(DEV1)) {
            ++countDev2;
        }
    }

    private String getCurrentTime() {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        return format.format(new Date());
    }

/*
    private boolean hasDuplicates(BluetoothDevice deviceTemp) {
        if (devices != null && devices.size() > 0)
            for (int i = 0; i < devices.size(); i++) {
                if (deviceTemp.getAddress().equals(devices.get(i).getAddress())) {
                    return true;
                }
            }
        return false;
    }
*/

    private int isMyDeviceToConnectInList(BluetoothDevice deviceTemp) {
        //from settings page get two devices as two points to and from: and keep monitoring only them; save them in sharedpref;
        //if its null in sharedoref then sho settings page
        //if (DevicesSharedPref)
        //demo testin gtaking first two paired as devices 1 n 2 //[[TEST]]
        if (context == null) {
            Log.i(TAG, "isMyDeviceToConnectInList: context is NULL ");
            return 0;
        }
        String DEV1 = DevicesSharedPref.getFirstdevice(context);  //moto
        String DEV2 = DevicesSharedPref.getSeconddevice(context);  //galaxy on7

        if (deviceTemp.getAddress().equals(DEV2)) {
            return 2;
        } else if (deviceTemp.getAddress().equals(DEV1)) {
            return 1;
        }
        Log.i(TAG, "isMyDeviceToConnectInList: " + deviceTemp.getAddress());
        return 0;
    }

    public void setActivity(NavigateActivity activity) {
        init(activity);
    }

    private void init(NavigateActivity activity) {
        this.activity = activity;
        //devices = new ArrayList<>();
    }
}
