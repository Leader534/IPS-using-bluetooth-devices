package com.btnavigate;

import android.content.Context;
import android.content.SharedPreferences;

public class DevicesSharedPref {
    private static final String SPREF_FILE = "SPREF_LOGIN";
    private static final String FIRSTDEVICE = "firstdevice";
    private static final String SECONDDEVICE = "seconddevice";
 private static final String FIRSTDEVICENAME = "firstdevicename";
    private static final String SECONDDEVICENAME = "seconddevicename";

    public static String getFirstdevice(Context context) {
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        return sprefLogin.getString(FIRSTDEVICE, "");
    }

    public static void setFirstdevice(Context context, String deviceAddress){
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sprefLogin.edit();
        editor.putString(FIRSTDEVICE, deviceAddress);
        editor.apply();
    }
    public static String getSeconddevice(Context context) {
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        return sprefLogin.getString(SECONDDEVICE, "");
    }

    public static void setSeconddevice(Context context, String deviceAddress){
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sprefLogin.edit();
        editor.putString(SECONDDEVICE, deviceAddress);
        editor.apply();
    }
    //
    public static String getFirstdeviceNAME(Context context) {
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        return sprefLogin.getString(FIRSTDEVICENAME, "");
    }

    public static void setFirstdeviceNAME(Context context, String deviceAddress){
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sprefLogin.edit();
        editor.putString(FIRSTDEVICENAME, deviceAddress);
        editor.apply();
    }
    public static String getSeconddeviceNAME(Context context) {
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        return sprefLogin.getString(SECONDDEVICENAME, "");
    }

    public static void setSeconddeviceNAME(Context context, String deviceAddress){
        SharedPreferences sprefLogin = context.getSharedPreferences(SPREF_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sprefLogin.edit();
        editor.putString(SECONDDEVICENAME, deviceAddress);
        editor.apply();
    }
}