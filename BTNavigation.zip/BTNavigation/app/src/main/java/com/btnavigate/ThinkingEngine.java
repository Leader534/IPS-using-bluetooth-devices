package com.btnavigate;

import android.util.Log;

public class ThinkingEngine {
    private static final String RIGHT = " RIGHT ";
    private static final String LEFT = " LEFT ";
    private static boolean firstCmdSpoken;
    private static final int LOW = -85; //-90 towards
    private static final int HIGH_STRENGTH_SIG = -70;//towards -60
    private static final String TAG = "TAG";

    public static String getCommands(int rssiOfDev, int devWhich) {
        Log.d(TAG, "getCommands: before" + firstCmdSpoken + " " + devWhich + rssiOfDev + " " + HIGH_STRENGTH_SIG);
        if (devWhich == 1 && !firstCmdSpoken && rssiOfDev >= HIGH_STRENGTH_SIG) {
            return whatCommand();
        } else if (devWhich == 2 && rssiOfDev >= HIGH_STRENGTH_SIG) {
            if (isFirstCmdSpoken())
                return whatCommand();
        }
        Log.i(TAG, "getCommands: end" + devWhich + " " + rssiOfDev);
        return null;
    }

    private static String whatCommand() {
        String command = null;
        switch (LocationsSelected.getFromSourceLoc()) {
            case LocationsSelected.HOD:
                switch (LocationsSelected.getToDestiLoc()) {
                    case LocationsSelected.OSSL:
                        command = RIGHT;
                        break;
                    case LocationsSelected.DSA:
                        command = RIGHT;
                }
                break;
            case LocationsSelected.OSSL:
                switch (LocationsSelected.getToDestiLoc()) {
                    case LocationsSelected.HOD:
                        command = LEFT;
                        break;
                    case LocationsSelected.DSA:
                        command = RIGHT;
                }
                break;
            case LocationsSelected.DSA:
                switch (LocationsSelected.getToDestiLoc()) {
                    case LocationsSelected.HOD:
                        command = LEFT;
                        break;
                    case LocationsSelected.OSSL:
                        command = LEFT;
                }

        }
        Log.i(TAG, "whatCommand: " + isFirstCmdSpoken() + LocationsSelected.getFromSourceLoc() + LocationsSelected.getToDestiLoc());
        if (!isFirstCmdSpoken()) //dont add commas to comment
        {
            setFirstCmdSpoken(true);

            return "You are currently at " + LocationsSelected.getFromSourceLoc() + ". Head to your " + command + " when you walk out of " + LocationsSelected.getFromSourceLoc() + " room and keep walking straight..";
        } else
            return "You have reached near " + LocationsSelected.getToDestiLoc() + ". Navigation completed";
    }

    public static boolean isFirstCmdSpoken() {
        return firstCmdSpoken;
    }

    public static void setFirstCmdSpoken(boolean firstCmdSpoken) {
        ThinkingEngine.firstCmdSpoken = firstCmdSpoken;
        Log.i(TAG, "setFirstCmdSpoken: ");
    }
}
