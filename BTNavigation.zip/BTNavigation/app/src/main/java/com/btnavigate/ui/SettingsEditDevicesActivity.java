package com.btnavigate.ui;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.btnavigate.DevicesSharedPref;
import com.btnavigate.R;

import java.util.ArrayList;
import java.util.Set;

public class SettingsEditDevicesActivity extends AppCompatActivity {

    private static final int RC_COARSE = 101;
    private Spinner spinFrom, spinTo;
    private BluetoothAdapter mBtAdapter;
    private ArrayList<String> deviceid;
    private ArrayList<String> bdata;
    private ArrayAdapter<String> adaptFrom, adaptTo;
    private static final String TAG = "TAG sett";
    private TextView tvDestinationDev, tvSourceDev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_edit_devices);
        initUI();
        setTitle("Settings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBtAdapter == null) {
            exitApp();
        } else if (!mBtAdapter.isEnabled()) {
            exitApp();
        }
    }

    private void exitApp() {
        Toast.makeText(this, "Please turn bluetooth ON", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            onBackPressed();
        } else if (item.getItemId() == R.id.mi_pair){
            goToPairNewDevices();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkLocationPermission();
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, RC_COARSE);
        else getPaired();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (RC_COARSE == requestCode && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getPaired();
        } else {
            ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        }
    }


    private void initUI() {
        spinFrom = (Spinner) findViewById(R.id.spinnerfrom);
        spinTo= (Spinner) findViewById(R.id.spinnerto);
        tvSourceDev = findViewById(R.id.tv_source_device);
        tvDestinationDev = findViewById(R.id.tv_destination_device);
        spinFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                //set from sharedpref and editable false ; until the list is found
                if (pos != 0) {
                    if (deviceid != null && deviceid.size() > 0)
                        if (!deviceid.get(pos).equalsIgnoreCase(DevicesSharedPref.getFirstdevice(SettingsEditDevicesActivity.this))) {
                            DevicesSharedPref.setFirstdevice(SettingsEditDevicesActivity.this, deviceid.get(pos));
                            String[] name = bdata.get(pos).trim().split("\\n");
                            DevicesSharedPref.setFirstdeviceNAME(SettingsEditDevicesActivity.this, name[0]);
                            tvSourceDev.setText("Saved Source Device");
                            Log.i(TAG, "onItemSelected: " + name[0]);
                        }
                }
                Log.i(TAG, "onItemSelected: " + pos + " " + DevicesSharedPref.getFirstdevice(SettingsEditDevicesActivity.this));

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                if (pos != 0) {
                    if (deviceid != null && deviceid.size() > 0)
                        if (!deviceid.get(pos).equalsIgnoreCase(DevicesSharedPref.getSeconddevice(SettingsEditDevicesActivity.this))) {
                            DevicesSharedPref.setSeconddevice(SettingsEditDevicesActivity.this, deviceid.get(pos));
                            String[] name =  bdata.get(pos).trim().split("\\n");
                            DevicesSharedPref.setSeconddeviceNAME(SettingsEditDevicesActivity.this, name[0]);
                            tvDestinationDev.setText("Saved Destination Device");
                            Log.i(TAG, "onItemSelected: " + name[0]);
                        }
                }
                Log.i(TAG, "onItemSelected: " + pos + " " + DevicesSharedPref.getSeconddevice(SettingsEditDevicesActivity.this));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_pair_new_device, menu);
        return true;
    }

    private void goToPairNewDevices(){
        Intent settingsIntent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
        startActivity(settingsIntent);
    }
    public void getPaired() {
        try {
            bdata = new ArrayList<String>();
            bdata.add(getResources().getString(R.string.select_dev));
            deviceid = new ArrayList<String>();
            deviceid.add("");
            Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
            if (pairedDevices.size() > 0) {
                for (BluetoothDevice device : pairedDevices) {
                    bdata.add(device.getName() + "\n" + device.getAddress());
                    deviceid.add(device.getAddress());
                }
            } else {

                AlertDialog.Builder ad = new AlertDialog.Builder(SettingsEditDevicesActivity.this);
                ad.setTitle("No devices");
                ad.setMessage("Add Devices to Paired List");
                ad.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                ad.setNeutralButton("Pair", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        Intent settingsIntent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                        startActivity(settingsIntent);
                    }
                });
                ad.show();
            }
            adaptFrom = new ArrayAdapter<String>(SettingsEditDevicesActivity.this, R.layout.spinitem, R.id.txt, bdata);
            spinFrom.setAdapter(adaptFrom);
            adaptTo = new ArrayAdapter<String>(SettingsEditDevicesActivity.this, R.layout.spinitem, R.id.txt, bdata);
            spinTo.setAdapter(adaptTo);
            setFromSharedPref();
        } catch (Exception ep) {
            Toast.makeText(SettingsEditDevicesActivity.this, ep.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void setFromSharedPref() {
        for (int i = 0; i < deviceid.size(); i++) {
            if (!DevicesSharedPref.getFirstdevice(SettingsEditDevicesActivity.this).isEmpty() && deviceid.get(i).compareTo(DevicesSharedPref.getFirstdevice(SettingsEditDevicesActivity.this)) == 0) {
                spinFrom.setSelection(i);
            } else   if (!DevicesSharedPref.getFirstdevice(SettingsEditDevicesActivity.this).isEmpty() && deviceid.get(i).compareTo(DevicesSharedPref.getSeconddevice(SettingsEditDevicesActivity.this)) == 0) {
                spinTo.setSelection(i);
            }
        }
    }

}
